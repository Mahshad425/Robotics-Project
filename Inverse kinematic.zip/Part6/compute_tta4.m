function [solutionList4] = compute_tta4(tta1,tta2,tta3,zee)
r13 = zee(1);
r23 = zee(2);
r33 = zee(3);

t11 = (cos(tta1)*sin(tta2)*sin(tta3) - cos(tta1)*cos(tta2)*cos(tta3));
t12 = -sin(tta1);
t21 = (sin(tta1)*sin(tta2)*sin(tta3) - cos(tta2)*cos(tta3)*sin(tta1));
t22 = cos(tta1);
t31 = sin(tta2 + tta3);
t32 = 0;

A = t11 * r13 + t21 * r23 + t31 * r33;
B = t12 * r13 + t22 * r23 + t32 * r33;

solutionList4 = [atan(-B/A) ,pi + atan(-B/A) , atan(-B/A) - pi];




end

