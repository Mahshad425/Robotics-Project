function [true_answers] = clean_answers(answers)
    cleaned_answers = rad2deg(unique(answers, 'rows'));
    true_answers = [];
    for i = transpose(cleaned_answers)
        if i(1) > -170 && i(1) < 170 && i(2) > -190 && i(2) < 45 && i(3) > -29 && i(3) < 256 && i(4) > -190 && i(4) < 190 && i(5) > -120 && i(5) < 120 && i(6) > -360 && i(6) < 360
            true_answers = [true_answers;transpose(i)];
        end
    end
end

