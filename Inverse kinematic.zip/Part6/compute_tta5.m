function [solutionList5] = compute_tta5(tta1,tta2,tta3,tta4,zee)
r13 = zee(1);
r23 = zee(2);
r33 = zee(3);

t11 = - (sin(tta1)*sin(tta4) + cos(tta4)*(cos(tta1)*sin(tta2)*sin(tta3) - cos(tta1)*cos(tta2)*cos(tta3)));
t12 = sin(tta2 + tta3)*cos(tta1);
t21 = (cos(tta1)*sin(tta4) - cos(tta4)*(sin(tta1)*sin(tta2)*sin(tta3) - cos(tta2)*cos(tta3)*sin(tta1)));
t22 =sin(tta2 + tta3)*sin(tta1);
t31 = - sin(tta2 + tta3)*cos(tta4);
t32 = cos(tta2 + tta3);

A = t11 * r13 + t21 * r23 + t31 * r33;
B = t12 * r13 + t22 * r23 + t32 * r33;

alpha = atan2(A,B);

solutionList5 = [alpha+acos(1/sqrt(A^2+B^2)), alpha-acos(1/sqrt(A^2+B^2))];



end

