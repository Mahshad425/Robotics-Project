clc;clear;close all
syms tta1 tta2 tta3 tta4 tta5 tta6
PI = sym(pi);
T1 = compute_DH_mod_tf(0,0,335/1000,tta1);
T2 = compute_DH_mod_tf(75/1000,-PI/2,0,tta2);
T3 = compute_DH_mod_tf(270/1000,0,0,tta3-PI);
T4 = compute_DH_mod_tf(90/1000,-PI/2,295/1000,tta4);
T5 = compute_DH_mod_tf(0,PI/2,0,tta5);
T6 = compute_DH_mod_tf(0,-PI/2,80/1000,tta6);
T10 = T1;
T20 = T10*T2;
T30 = T20 * T3;
T40 = simplify(T30 * T4);
T50 = simplify(T40 * T5);
T60 = simplify(T50 * T6);

%% 
Tee_example = double(vpa(subs(T60,[tta1 tta2 tta3 tta4 tta5 tta6],deg2rad([0 -90 180 0 0 0])), 3))
zee = Tee_example(1:3,3);
xee = Tee_example(1:3,1);
Pee = Tee_example(1:3,4);
P = Pee - zee * 0.08;
[q1,solutionList2,solutionList3] = (compute_inv_position(P(1),P(2),P(3)));
disp("first loop")
for i2 = real(solutionList2(1,:))
    for i3 = real(solutionList3(1,:))
        solutionList4 = real(compute_tta4(q1,i2,i3,zee));
        for i4 = solutionList4
            solutionList5 = real(compute_tta5(q1,i2,i3,i4,zee));
            for i5 = solutionList5
                solutionList6 = real(compute_tta6(q1,i2,i3,i4,i5,xee));
                counter = 1;
                for i6 = solutionList6
                    possible_answer = vpa(subs(T60,[tta1 tta2 tta3 tta4 tta5 tta6], [q1 i2 i3 i4 i5 i6]), 3);
                    if(mapSymType(vpa(possible_answer-Tee_example), 'vpareal', @(x) piecewise(abs(x)<=1e-5, 0, x)) == zeros(4))
                         answers(counter,1:6) = [q1 i2 i3 i4 i5 i6];
                         counter=counter+1;
                    end
                end
           end
        end
    end
end
disp("second loop")
for i2 = solutionList2(2,:)
    for i3 = solutionList3(2,:)
        solutionList4 = real(compute_tta4(q1,i2,i3,zee));
        for i4 = solutionList4
            solutionList5 = real(compute_tta5(q1,i2,i3,i4,zee));
            for i5 = solutionList5
                solutionList6 = real(compute_tta6(q1,i2,i3,i4,i5,xee));
                for i6 = solutionList6
                    possible_answer = vpa(subs(T60,[tta1 tta2 tta3 tta4 tta5 tta6], [q1 i2 i3 i4 i5 i6]), 3);
                    if(mapSymType(vpa(possible_answer-Tee_example), 'vpareal', @(x) piecewise(abs(x)<=1e-5, 0, x)) == zeros(4))
                         answers(counter,1:6) = [q1 i2 i3 i4 i5 i6];
                         counter=counter+1;
                    end
               end  
           end
            
        end
    end
end
true_answers = clean_answers(answers)

