function [solutionList6] = compute_tta6(tta1,tta2,tta3,tta4,tta5,xee)
r11 = xee(1);
r21 = xee(2);
r31 = xee(3);

t11 = (cos(tta4)*sin(tta1) - sin(tta4)*(cos(tta1)*sin(tta2)*sin(tta3) - cos(tta1)*cos(tta2)*cos(tta3)));
t12 = (cos(tta5)*(sin(tta1)*sin(tta4) + cos(tta4)*(cos(tta1)*sin(tta2)*sin(tta3) - cos(tta1)*cos(tta2)*cos(tta3))) + sin(tta2 + tta3)*cos(tta1)*sin(tta5));
t21 = -(cos(tta1)*cos(tta4) + sin(tta4)*(sin(tta1)*sin(tta2)*sin(tta3) - cos(tta2)*cos(tta3)*sin(tta1)));
t22 = -(cos(tta5)*(cos(tta1)*sin(tta4) - cos(tta4)*(sin(tta1)*sin(tta2)*sin(tta3) - cos(tta2)*cos(tta3)*sin(tta1))) - sin(tta2 + tta3)*sin(tta1)*sin(tta5));
t31 = - sin(tta2 + tta3)*sin(tta4);
t32 = (cos(tta2 + tta3)*sin(tta5) + sin(tta2 + tta3)*cos(tta4)*cos(tta5));

A = t11 * r11 + t21 * r21 + t31 * r31;
B = t12 * r11 + t22 * r21 + t32 * r31;

alpha = atan2(A,B);

solutionList6 = [alpha+acos(1/sqrt(A^2+B^2)), alpha-acos(1/sqrt(A^2+B^2))];





end

